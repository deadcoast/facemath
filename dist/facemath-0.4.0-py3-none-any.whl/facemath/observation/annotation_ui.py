"""Create a portable, offline, prediction-blind reference annotation workspace.

No detector coordinates are accepted by this function. Annotation identity and
blinding are user declarations, not guarantees about the person using a browser.
"""

from __future__ import annotations

import json
from base64 import b64encode
from html import escape
from pathlib import Path

import cv2
import numpy as np

from .contracts import ObservationError, array_digest, rgb_image
from .reference import (
    REFERENCE_DEFINITIONS,
    REFERENCE_NAMES,
    REFERENCE_PROTOCOL_SHA256,
)


def create_annotation_workspace(
    image: np.ndarray,
    destination: str | Path,
    *,
    source: str,
    kind: str = "human_blind",
) -> Path:
    image = rgb_image(image)
    if kind not in ("human_blind", "synthetic_fixture"):
        raise ObservationError(
            "workspace requires an explicit blind/external/synthetic reference kind"
        )
    if not isinstance(source, str) or not source.strip():
        raise ObservationError("annotation workspace requires a source description")
    ok, encoded = cv2.imencode(".png", cv2.cvtColor(image, cv2.COLOR_RGB2BGR))
    if not ok:
        raise ObservationError("annotation image encoding failed")
    payload = {
        "names": REFERENCE_NAMES,
        "definitions": REFERENCE_DEFINITIONS,
        "image_sha256": array_digest(image),
        "image_shape": image.shape[:2],
        "protocol_sha256": REFERENCE_PROTOCOL_SHA256,
        "source": source,
        "kind": kind,
        "image": f"data:image/png;base64,{b64encode(encoded).decode()}",
    }
    # JSON text lives in a script data element; escape closing tags and separators.
    data = (
        json.dumps(payload, ensure_ascii=True)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )
    html = TEMPLATE.replace("__SOURCE_LABEL__", escape(source)).replace(
        "__PAYLOAD__", data
    )
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(html)
    return path


TEMPLATE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; font-src 'none'; base-uri 'none'">
<title>FACEMATH / Reference workbench</title><style>
:root{--bg:#11171d;--panel:#19232c;--ink:#e9f0f4;--muted:#a5b6c2;--line:#33444f;--accent:#7ee0d4;--amber:#edbe78}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,sans-serif}
main{max-width:1460px;margin:auto;padding:28px 30px 50px}header{border-bottom:1px solid var(--line);padding-bottom:20px;display:flex;justify-content:space-between;gap:25px;align-items:end}
.eyebrow{font:11px ui-monospace,monospace;letter-spacing:.16em;color:var(--accent)}h1{font-size:31px;letter-spacing:-.035em;margin:10px 0 3px}h2{font-size:17px;margin:0 0 10px}
p{color:var(--muted);margin:5px 0 10px}.badge{font:11px ui-monospace,monospace;display:inline-block;padding:7px 10px;border:1px solid var(--line);white-space:nowrap}
.layout{display:grid;grid-template-columns:minmax(0,1fr) 315px;gap:20px;margin-top:24px}.stage{min-width:0}.toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding-bottom:10px}.toolbar span{margin-left:auto;font:12px ui-monospace,monospace;color:var(--muted)}
button,input{font:inherit}button{background:var(--panel);border:1px solid var(--line);color:var(--ink);padding:8px 12px;cursor:pointer;border-radius:3px}button:hover{border-color:var(--accent)}button:focus-visible,input:focus-visible{outline:2px solid var(--accent);outline-offset:3px}button:disabled{opacity:.35;cursor:not-allowed}
#stage{display:block;width:100%;height:530px;background:#080d11;border:1px solid var(--line);touch-action:none;cursor:crosshair}#status{min-height:28px;padding-top:8px;color:var(--amber);font-size:13px}.hint{font-size:12px;color:var(--muted);padding:9px 0}.panel{background:var(--panel);padding:16px;border:1px solid var(--line)}
#point-list{display:grid;gap:5px}#point-list button{width:100%;text-align:left;font-size:13px;padding:8px 10px;display:flex;align-items:center;gap:9px}#point-list button.current{border-color:var(--accent);background:#243941}.marker{font:11px ui-monospace,monospace;display:inline-grid;place-items:center;border:1px solid var(--line);width:23px;height:23px;flex:none}.placed .marker{color:var(--accent);border-color:var(--accent)}.hidden .marker{color:var(--amber);border-color:var(--amber)}.state{margin-left:auto;font-size:10px;color:var(--muted)}
#instruction{min-height:55px;font-size:13px;margin:10px 0}.actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:12px}.micro{font-size:11px;color:var(--muted)}label{display:block;font-size:12px;color:var(--muted);margin:16px 0 5px}input{width:100%;padding:9px;color:var(--ink);background:#0e171e;border:1px solid var(--line);border-radius:3px}.export{width:100%;margin-top:14px;background:#23524d;border-color:#519c93}#lens{display:block;width:148px;height:148px;background:#0a1116;border:1px solid var(--line)}.bottom{display:flex;gap:15px;align-items:center;border-top:1px solid var(--line);padding-top:15px;margin-top:12px}code{font:11px ui-monospace,monospace;overflow-wrap:anywhere}footer{margin-top:22px;padding-top:14px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}.progress{height:3px;background:var(--line);margin:10px 0 14px}.progress div{height:100%;background:var(--accent);width:0;transition:width .1s}
@media(max-width:800px){main{padding:18px 12px}header{align-items:start;flex-direction:column;gap:10px}.layout{grid-template-columns:1fr;gap:12px}#stage{height:400px}.panel{padding:12px}#point-list{grid-template-columns:1fr 1fr}#point-list button{padding:7px;font-size:12px}.state{display:none}h1{font-size:26px}}
</style></head><body><main><header><div><div class="eyebrow">FACEMATH / WAVE 04 / INDEPENDENT REFERENCE</div><h1>Annotate what is observable.</h1><p>Eight source-coordinate landmarks. No detector prediction is shown.</p></div><div><span class="badge" id="kind"></span> <span class="badge">OFFLINE · NO NETWORK</span></div></header>
<div class="layout"><section class="stage"><div class="toolbar"><button id="fit">Fit</button><button id="zoom-in" aria-label="Zoom in">＋</button><button id="zoom-out" aria-label="Zoom out">−</button><button id="undo">Undo</button><button id="redo">Redo</button><span id="zoom-state">1.0×</span></div><canvas id="stage" tabindex="0" aria-label="Source image annotation canvas"></canvas><div id="status" role="status" aria-live="polite"></div><div class="hint">Click to locate · wheel / ＋ / − to zoom · Alt-drag to pan · arrows to nudge 0.25 px · Shift-arrows 1 px · [ / ] select point · X unobservable</div><div class="bottom"><canvas id="lens" width="148" height="148" aria-label="Magnified source pixels"></canvas><div><h2>Pixel view</h2><p id="coordinate">Move over the source image.</p><p class="micro">The crosshair is only a cursor. A coordinate enters the reference only after an explicit click. Hidden or ambiguous anatomy should be marked unobservable, not guessed.</p></div></div></section>
<aside class="panel"><h2 id="progress-label">0 / 8 resolved</h2><div class="progress"><div id="progress-bar"></div></div><div id="point-list"></div><p id="instruction"></p><div class="actions"><button id="unobservable">Unobservable (X)</button><button id="clear">Clear point</button></div><label for="rater">Independent rater ID</label><input id="rater" autocomplete="off" placeholder="e.g. annotator-02" maxlength="100"><p class="micro">Blinding and authorship are your declarations. This file cannot verify them. Use a different ID for each actual rater.</p><label for="note">Acquisition / visibility note</label><input id="note" autocomplete="off" placeholder="Optional source limitation" maxlength="500"><button id="export" class="export" disabled>Export reference JSON</button><p class="micro" id="save-state">Draft saving begins after a rater ID is entered. No data leaves this browser.</p></aside></div>
<footer>Source: __SOURCE_LABEL__<br>Image-bound SHA-256: <code id="digest"></code><br>Coordinates remain in original image pixels at every zoom. Annotations are not detection outputs, geometric scores, or population references.</footer></main>
<script id="payload" type="application/json">__PAYLOAD__</script><script>
'use strict';
const data=JSON.parse(document.getElementById('payload').textContent), $=id=>document.getElementById(id);
const canvas=$('stage'), ctx=canvas.getContext('2d'), lens=$('lens').getContext('2d'), image=new Image();
let activeRater="", points=Array(8).fill(null), active=0, history=[], future=[], events=[], view={scale:1,tx:0,ty:0}, baseScale=1, lastPointer=null, drag=null;
const height=data.image_shape[0], width=data.image_shape[1];
$('digest').textContent=data.image_sha256;$('kind').textContent=data.kind.toUpperCase().replaceAll('_',' ');
function announce(text){$('status').textContent=text;}
function copy(x){return JSON.parse(JSON.stringify(x));}
function save(){const id=$('rater').value.trim();if(!id)return;try{localStorage.setItem('facemath.ref4:'+data.image_sha256+':'+id,JSON.stringify({points,events,note:$('note').value}));$('save-state').textContent='Draft saved locally for '+id+'.';}catch(e){$('save-state').textContent='Browser draft storage unavailable; export before closing.';}}
function commit(action){history.push(copy(points));future=[];action();events.push({action:'edit',landmark:data.names[active],value:copy(points[active]),utc:new Date().toISOString()});save();render();}
function fit(){const r=canvas.getBoundingClientRect();baseScale=Math.min((r.width-20)/width,(r.height-20)/height);view={scale:baseScale,tx:(r.width-width*baseScale)/2,ty:(r.height-height*baseScale)/2};draw();}
function resize(){const r=canvas.getBoundingClientRect(),d=window.devicePixelRatio||1;canvas.width=Math.round(r.width*d);canvas.height=Math.round(r.height*d);ctx.setTransform(d,0,0,d,0,0);fit();}
function sourceAt(x,y){return [(x-view.tx)/view.scale,(y-view.ty)/view.scale];}
function draw(){if(!image.complete)return;const r=canvas.getBoundingClientRect();ctx.clearRect(0,0,r.width,r.height);ctx.imageSmoothingEnabled=view.scale<2;ctx.drawImage(image,view.tx,view.ty,width*view.scale,height*view.scale);points.forEach((p,i)=>{if(!p||!p.visible)return;const x=p.xy[0]*view.scale+view.tx,y=p.xy[1]*view.scale+view.ty;ctx.strokeStyle=i===active?'#edbe78':'#7ee0d4';ctx.lineWidth=i===active?2:1;ctx.beginPath();ctx.arc(x,y,5,0,2*Math.PI);ctx.moveTo(x-10,y);ctx.lineTo(x+10,y);ctx.moveTo(x,y-10);ctx.lineTo(x,y+10);ctx.stroke();ctx.font='12px ui-monospace,monospace';ctx.fillStyle='#fff';ctx.fillText(String(i+1),x+8,y-8);});$('zoom-state').textContent=(view.scale/baseScale).toFixed(1)+'×';}
function render(){const count=points.filter(Boolean).length;$('progress-label').textContent=count+' / 8 resolved';$('progress-bar').style.width=(100*count/8)+'%';$('point-list').replaceChildren();data.names.forEach((name,i)=>{const b=document.createElement('button');b.type='button';b.className=(i===active?'current ':'')+(points[i]?(points[i].visible?'placed':'hidden'):'');b.setAttribute('aria-label','Select '+name);b.setAttribute('aria-pressed',i===active?'true':'false');const m=document.createElement('span');m.className='marker';m.textContent=String(i+1);const t=document.createElement('span');t.textContent=name.replaceAll('_',' ');const s=document.createElement('span');s.className='state';s.textContent=points[i]?(points[i].visible?'SET':'HIDDEN'):'—';b.append(m,t,s);b.onclick=()=>{active=i;render();};$('point-list').append(b);});$('instruction').textContent=data.definitions[active];$('undo').disabled=!history.length;$('redo').disabled=!future.length;$('export').disabled=count!==8||!$('rater').value.trim();draw();}
function zoom(factor,x,y){const r=canvas.getBoundingClientRect();x=x??r.width/2;y=y??r.height/2;const p=sourceAt(x,y),s=Math.min(baseScale*16,Math.max(baseScale*.5,view.scale*factor));view={scale:s,tx:x-p[0]*s,ty:y-p[1]*s};draw();}
function pointer(e){const r=canvas.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top];}
canvas.addEventListener('pointerdown',e=>{canvas.focus();const [x,y]=pointer(e);if(e.altKey||e.button===1){drag={x,y,tx:view.tx,ty:view.ty};canvas.setPointerCapture(e.pointerId);return;}if(e.button!==0)return;const p=sourceAt(x,y);if(p[0]<0||p[1]<0||p[0]>width-1||p[1]>height-1){announce('Click inside the original source raster.');return;}commit(()=>{points[active]={visible:true,xy:p.map(v=>Math.round(v*1000)/1000)};});announce('Recorded '+data.names[active]+'.');});
canvas.addEventListener('pointerup',()=>{drag=null;});canvas.addEventListener('pointercancel',()=>{drag=null;});
canvas.addEventListener('pointermove',e=>{const [x,y]=pointer(e);lastPointer=[x,y];if(drag){view.tx=drag.tx+x-drag.x;view.ty=drag.ty+y-drag.y;draw();}const p=sourceAt(x,y);$('coordinate').textContent='x '+p[0].toFixed(2)+' · y '+p[1].toFixed(2)+' source px';lens.clearRect(0,0,148,148);lens.imageSmoothingEnabled=false;lens.drawImage(image,p[0]-12,p[1]-12,24,24,0,0,148,148);lens.strokeStyle='#edbe78';lens.lineWidth=1;lens.beginPath();lens.moveTo(74,0);lens.lineTo(74,148);lens.moveTo(0,74);lens.lineTo(148,74);lens.stroke();});
canvas.addEventListener('wheel',e=>{e.preventDefault();const p=pointer(e);zoom(e.deltaY<0?1.15:1/1.15,...p);},{passive:false});
$('fit').onclick=fit;$('zoom-in').onclick=()=>zoom(1.5);$('zoom-out').onclick=()=>zoom(1/1.5);
$('undo').onclick=()=>{if(!history.length)return;future.push(copy(points));points=history.pop();events.push({action:'undo',utc:new Date().toISOString()});save();render();};
$('redo').onclick=()=>{if(!future.length)return;history.push(copy(points));points=future.pop();events.push({action:'redo',utc:new Date().toISOString()});save();render();};
$('unobservable').onclick=()=>commit(()=>{points[active]={visible:false,xy:[0,0]};});$('clear').onclick=()=>commit(()=>{points[active]=null;});
function validDraft(draft){return Array.isArray(draft.points)&&draft.points.length===8&&draft.points.every(p=>p===null||(p&&typeof p.visible==='boolean'&&Array.isArray(p.xy)&&p.xy.length===2&&p.xy.every(Number.isFinite)&&(p.visible?(p.xy[0]>=0&&p.xy[0]<=width-1&&p.xy[1]>=0&&p.xy[1]<=height-1):(p.xy[0]===0&&p.xy[1]===0))));}
$('rater').addEventListener('change',()=>{const id=$('rater').value.trim();if(activeRater&&id!==activeRater){points=Array(8).fill(null);history=[];future=[];events=[];$('note').value='';announce('Changed rater: previous annotations are not shown.');}activeRater=id;try{const raw=localStorage.getItem('facemath.ref4:'+data.image_sha256+':'+id);if(raw){const draft=JSON.parse(raw);if(validDraft(draft)&&confirm('Restore the local draft for this rater?')){points=draft.points;events=Array.isArray(draft.events)?draft.events:[];$('note').value=String(draft.note||'');history=[];future=[];}else if(!validDraft(draft)){announce('Invalid saved draft ignored; current source coordinates were not replaced.');}}}catch(e){}render();});
$('rater').addEventListener('input',render);$('note').addEventListener('input',save);
window.addEventListener('keydown',e=>{if(e.target.matches('input,textarea'))return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();$(e.shiftKey?'redo':'undo').click();return;}if(e.key==='['||e.key===']'){active=(active+(e.key===']'?1:7))%8;render();}if(e.key.toLowerCase()==='x')$('unobservable').click();if(e.key==='Backspace'){e.preventDefault();$('clear').click();}if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)&&points[active]?.visible){e.preventDefault();const step=e.shiftKey?1:.25;commit(()=>{const p=points[active].xy;p[0]=Math.max(0,Math.min(width-1,p[0]+(e.key==='ArrowRight'?step:e.key==='ArrowLeft'?-step:0)));p[1]=Math.max(0,Math.min(height-1,p[1]+(e.key==='ArrowDown'?step:e.key==='ArrowUp'?-step:0)));});}});
function exportReference(){if(points.some(p=>p===null)||!$('rater').value.trim())return null;return {format:'facemath.reference.v4',protocol_sha256:data.protocol_sha256,names:data.names,image_sha256:data.image_sha256,image_shape:data.image_shape,xy:points.map(p=>p.xy),visible:points.map(p=>p.visible),rater_id:$('rater').value.trim(),kind:data.kind,source:data.source,prediction_exposure:'none_declared',metadata:{interface:'facemath.reference-workbench.v4',note:$('note').value,ui_event_history:events,authorship:'declared_by_operator_not_attested'}};}
$('export').onclick=()=>{const obj=exportReference();if(!obj)return;const blob=new Blob([JSON.stringify(obj,null,2)+'\n'],{type:'application/json'}),a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download='reference_'+data.image_sha256.slice(0,12)+'_'+$('rater').value.replace(/[^a-zA-Z0-9_-]/g,'_')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);announce('Exported image-bound reference JSON.');};
image.onload=()=>{resize();render();};image.src=data.image;window.addEventListener('resize',resize);render();
</script></body></html>"""
