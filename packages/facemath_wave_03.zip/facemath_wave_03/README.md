# FACEMATH 0.3 — The observed-correspondence instrument

**One anatomical observation state. One declared registration gauge. A dense geometric field. Independently checkable evidence.**

FACEMATH measures projected facial layout and shape differences. It does not identify people, infer relationships, or turn detector confidence into a percentage of resemblance. Wave 3 extends the actual Wave 2 package; the inherited research modules remain available, with an explicit audit of what they do and do not implement.

The active instrument lives in `facemath.observation`. It runs end to end on image-bound annotations or on observations from the optional local MediaPipe provider. The release includes executable controls, source, tests, a self-contained HTML report, raw arrays, and verifiable execution artifacts.

## Start here

From the extracted project directory:

```sh
python -m pip install -e ".[dev]"
python -m facemath demo --out runs/demo
python -m facemath verify runs/demo
python -m facemath replay runs/demo --out runs/demo-replay
```

Open `runs/demo/report.html` in a browser. This demonstration is a **known-geometry schematic**, not a human study and not a detector demonstration. The opacity slider changes only the display. It never changes measurements.

The bundled wheel can alternatively be installed with `python -m pip install dist/facemath-0.3.0-py3-none-any.whl`. Dependencies must already exist or be available to pip. The project supports Python 3.11+ in its package contract; the captured release validation states exactly which interpreter was executed. A configured CI matrix is not a claim that those other environments have run.

## What Wave 3 changes

```text
independent source images
        |
image-bound observation + retained whole-shape perturbation samples
        |
shared named anatomical grammar
        |
symmetric robust registration + source-support masks
        |
immutable CanonicalState
        |
        +-- piecewise-affine anatomical displacement/Jacobian/strain
        +-- independent raster flow / cycle / texture diagnostics
        +-- held-out-region registration sensitivity
        +-- joint observation resampling with transform refits
        |
regional measured profile + actual execution journal
        |
raw NPZ + strict JSON + self-contained report + integrity manifest
        |
optional compatible, leakage-checked reference cohort
```

Measurements do not establish separate coordinate systems. A single `CanonicalState` supplies the same observations, transforms, units, masks, configuration, and recipe identity throughout the analysis. Flow is deliberately **not blended into landmark evidence**: agreement between two derived methods is useful to inspect, but it must not create circular confidence.

## Actual execution status

| Component | Release status |
|---|---|
| Observation contracts, registration, dense field, regional metrics, conditional sensitivity | Executed against analytic and synthetic controls |
| CLI, bundle integrity, raw-state replay, cohort ingestion | Executed in local tests and release checks |
| 478-point geometry/schema path | Executed with an explicitly synthetic fixture |
| MediaPipe API adapter and augmentation remapping | Implemented; fixture-based contract tests executed |
| Real MediaPipe model inference | **Not executed in this environment**; package/model acquisition failed. The live integration test is skipped unless real assets are supplied |
| OpenCV coarse face-region proposals on the supplied recording | Executed; these are boxes, not landmarks |
| Supplied video sampling and editing diagnostics | Executed; no portrait-pair similarity conclusion produced |
| Human-population calibration | No human cohort included |
| Historical proprietary model activations | Not acquired and not represented by these artifacts |

See `evidence/VALIDATION.json`, `evidence/pytest.xml`, and `evidence/coverage.txt` for the completed release's counts and environment. The live-observer skip is a limitation, not a passing test.

## Automatic observation with an explicit local model

The official FaceLandmarker task needs both its Python package and a compatible `.task` model. Install the optional extra and obtain the model separately; instructions and official references are in `models/README.md` and `docs/SOURCES.md`.

```sh
python -m pip install -e ".[observer]"
python -m facemath observe face_a.png --model models/face_landmarker.task --out a.observation.json
python -m facemath observe face_b.png --model models/face_landmarker.task --out b.observation.json
python -m facemath analyze face_a.png face_b.png --observation-a a.observation.json --observation-b b.observation.json --out runs/pair
```

The shorter `analyze ... --model models/face_landmarker.task` form observes both inputs during the run. `--model-sha256` verifies a digest supplied by the operator. No command silently downloads weights. Images must contain one selected face each; absent or ambiguous primary detections fail rather than generate substitute landmarks.

The provider retains the original predicted coordinates, augmentation transforms, normalized XYZ outputs, returned blendshape scores, successful sample labels, and failed augmentation reasons. The named regions are model-inferred anatomy. They are **not independent edge-detector ground truth**. The Z output is not used as metric 3D anatomy.

Seven controlled input variants probe repeatability: identity, two small rotations, two scale changes, and two gamma changes. Their full shapes are mapped back into source coordinates. The default 0.75-pixel residual noise floor is an explicit assumption, adjustable by `observe --sigma`; it is not an empirically validated error bound.

## Explicit annotations

`examples/semantic21.template.json` defines the names and coordinate order. Coordinates are source-image pixels, X then Y; left/right means viewer-side in the defined frontal convention.

```sh
python -m facemath import-annotation face_a.png annotations_a.json --annotation-id operator-a-001 --sigma 1.0 --out a.observation.json
```

This path is usable without MediaPipe. Image hashing binds the coordinates to the exact decoded RGB raster. Reusing the observation with a cropped, resized, edited, or different image fails. Annotations remain identified as operator-supplied, never as machine detections.

## What the numbers mean

`geometry.<region>.rms` is RMS landmark displacement divided by the geometric mean of the registered interocular spans. Zero means the evaluated coordinates coincide under this registration, not that identities are equal.

`geometry.<region>.within_tolerance` is the actual fraction of evaluated landmarks below `--tolerance` (default 0.05 spans). It has a numerator, denominator, and declared threshold. Multiplying that fraction by 100 is legitimate; calling it a general facial-similarity probability is not.

`registration.heldout_<region>.rms` excludes the evaluated region from alignment anchors. This reveals how strongly the alignment itself helped that region look similar. It is a sensitivity diagnostic, not an independent subject or extra sample.

`deformation.<region>.log_stretch_rms` aggregates local singular-value stretches of the piecewise-affine map. Rigid finite rotations have zero stretch. These are distortions of an interpolated geometry model, not measurements of tissue mechanics. The dense field is directional A→B; landmark RMS measurements are exchange-symmetric.

`flow.<region>.anatomical_disagreement` compares an independently estimated image-motion field with the anatomical interpolation. Flat, unobservable, out-of-domain, or cycle-inconsistent pixels are excluded. Low cycle error alone is not a probability of correct anatomical correspondence.

Intervals are **conditional observation-sensitivity intervals**, generated by resampling whole-shape perturbations, adding the declared pixel-noise floor, and refitting registration each time. They do not capture unknown shared detector bias or establish detector accuracy.

## Raw evidence and replay

Every successful pair run publishes a new directory, never silently replaces one:

```text
report.html                 interactive, offline inspection
source_a.png / source_b.png  exact decoded source RGB rasters
canonical_a.png / ...        one registered display chart
landmark_overlay.png        observed positional residuals
observations.json           source coordinates + repeatability samples + metadata
arrays.npz                  complete exported numerical state, no pickle
                         -> coordinates, transforms, covariances, masks,
                            triangle topology, Jacobians, finite strain,
                            log stretch, residuals, holdouts, sensitivity,
                            independent flow diagnostics
measurement data in evidence.json
                                units, support, missingness, interpretation
context in environment.json     versions and engine-source digest
actual steps in events.jsonl     begin/end/error events, input/output digests
integrity in manifest.json       file and array hashes, shapes, dtypes
```

`verify` checks recorded bytes, the array inventory, and the event chain. `replay` uses the stored rasters and observations, verifies matching source and numerical runtime, reruns the instrument, and compares numerical state. It does **not** claim bit-identical timing logs or repeat the original detector inference.

Hashes establish internal consistency. They do not independently prove authorship, provide a trusted timestamp, or authenticate data against an external adversary who can replace both files and manifest. No hidden activations are implied.

## Video input is a separate acquisition problem

```sh
python -m facemath inspect-video transition.mp4 --frames 32 --out runs/video-inspection
python -m facemath locate selected_frame.png --out roi-proposals.json
```

`inspect-video` records decoded frame identities, sample timestamps, source hash, spectra, affine-mixture residuals, and a labeled contact sheet. `--roi X Y W H` explicitly records a selected crop. It does not silently declare sampled endpoints to be clean photographs.

A linear crossfade of **any** two images has uncentered rank at most two and centered rank at most one. Smooth blending and a dominant low-rank component are therefore not independent evidence of facial similarity. The regression suite proves this with unrelated random textures. The inherited Wave 2 low-rank interpretation is superseded; see the audit.

## Reference cohorts, without synthetic population claims

```sh
python -m facemath cohort-create runs/control1 runs/control2 runs/control3 --name controlled-reference --kind synthetic --out reference.json
python -m facemath calibrate runs/query --cohort reference.json --metric geometry.all.rms --out rank.json
```

The ingestion path verifies every source bundle, requires identical recipes, retains source manifest hashes, and rejects missing requested metrics or duplicate image pairs. Real observational cohorts use `--kind observational`. Supplied synthetic evidence cannot be relabeled as an observational population.

Query images cannot appear in the reference. Optional caller-declared subject identifiers detect reuse through different images. Connected components of shared images/subjects, not naïvely independent pair rows, determine bootstrap resampling. Fewer than three independent components produce no interval. The per-metric rank is specific to that cohort; marginal ranks are never averaged into a purported joint percentile.

## Tests and mathematical status

```sh
python -m pytest -q
python -m coverage run -m pytest -q
python -m coverage report
python -m facemath laboratory --out controls.json
python -m facemath capabilities --out capability-audit.json
```

Live observer validation is opt-in through `FACEMATH_MODEL` and `FACEMATH_FACE`, plus an installed compatible MediaPipe package. No model-free test can validate its real detection accuracy.

The original sections 20–180 registry is preserved for compatibility. A function name mapped to a section is **not** proof that the described mathematics was implemented. `capabilities` explicitly distinguishes implemented instrument work, approximate methods, missing exact equivalents, conceptual claims, and external-telemetry requirements. Sections 0–19 were omitted in the inherited registry. There is no renewed claim that every equation is complete.

See `docs/ARCHITECTURE.md`, `docs/MATHEMATICS.md`, `docs/WAVE3_AUDIT.md`, and `docs/ROADMAP.md` for engineering decisions and remaining work. Legacy `compare` and `sequence` commands are retained with a warning; they are not the validated Wave 3 observation instrument.
