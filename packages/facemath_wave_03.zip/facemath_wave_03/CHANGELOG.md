# Changelog

## 0.3.0 — Observed correspondence / Wave 3

Added strict immutable image-bound observations, a shared anatomical grammar, a local optional MediaPipe provider with complete-shape augmentation samples, symmetric robust registration, held-out regional gauge diagnostics, exact piecewise-affine finite-strain geometry, independent texture/cycle-qualified image flow, conditional sensitivity refitting, compatible-cohort ingestion, leakage/dependence checks, raw-state bundles, offline HTML inspection, integrity verification, numeric replay, partial failure journals, and analytic/synthetic falsification tests.

Repaired signed-scale proper registration, implicit reflection behavior, mutating CKA, undirected Laplacian input/isolated-node handling, temporal mask use, and the low-rank-video interpretation. Added an honest mathematical capability audit instead of equating a section-name registry with complete implementation.

Retained the original research modules and legacy commands for continuity. They are not all fully audited or proven equivalent to every equation in the prior discussion. The real MediaPipe inference integration remains explicitly unexecuted in the captured environment; no human calibration population or detector weights are included.
